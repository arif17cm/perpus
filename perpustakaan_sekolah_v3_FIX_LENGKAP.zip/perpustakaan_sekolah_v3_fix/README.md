# Perpustakaan Sekolah V3 FIX

Aplikasi perpustakaan sekolah Flask + SQLite untuk LAN.

Fitur:
- Login admin
- Data siswa dan buku
- Peminjaman/pengembalian
- Scan QR dengan kamera HP
- Dukungan scanner USB (seperti keyboard)
- QR siswa dan QR buku
- Dashboard dan riwayat transaksi
- Export Excel/PDF
- Backup database
- HTTPS LAN melalui Nginx + Gunicorn
- Tidak memakai database eksternal

## Instalasi cepat

```bash
cd ~/perpus
unzip perpustakaan_sekolah_v3_fix.zip
cd perpustakaan_sekolah_v3_fix
chmod +x install.sh
./install.sh
```

Installer meminta password sudo bila diperlukan, memasang paket sistem, membuat virtualenv, memasang Python package, membuat sertifikat HTTPS untuk IP LAN, membuat service systemd Gunicorn, dan konfigurasi Nginx.

Akses:
- `https://IP-SERVER/`
- Scan: `https://IP-SERVER/scan`

Login awal:
- Username: `admin`
- Password: `admin123`

## Penting untuk kamera HP

HTTPS harus dibuka dengan `https://`, bukan `http://`.

Karena sertifikat dibuat sendiri untuk LAN, Chrome dapat menampilkan peringatan sertifikat. Pilih Lanjutan/Advanced lalu lanjutkan ke situs. Setelah halaman dibuka melalui HTTPS, izinkan kamera.

## Jika IP server berubah

Jalankan:
```bash
sudo ~/perpus/perpustakaan_sekolah_v3_fix/update_https.sh
```
atau jalankan lagi:
```bash
./install.sh
```

## Scanner USB

Scanner barcode/QR USB yang bekerja sebagai keyboard dapat digunakan pada halaman Scan. Pilih mode `Scanner USB`, fokus akan diarahkan ke kolom scan. Setelah kode masuk dan diakhiri Enter, aplikasi memproses otomatis.

## Data

Database berada di:
`instance/perpustakaan.db`

Backup dapat dibuat dari menu Backup.
