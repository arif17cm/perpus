#!/bin/bash
set -e
APP_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$APP_DIR"

echo "=== Instalasi Perpustakaan Sekolah V3 FIX ==="
sudo apt-get update
sudo apt-get install -y python3-venv python3-pip nginx openssl

if [ ! -d .venv ]; then
  python3 -m venv .venv
fi
.venv/bin/python -m pip install --upgrade pip
.venv/bin/pip install -r requirements.txt

mkdir -p certs instance

IP="$(hostname -I | awk '{print $1}')"
if [ -z "$IP" ]; then
  echo "Tidak menemukan IP LAN."
  exit 1
fi

echo "IP LAN terdeteksi: $IP"

cat > certs/openssl.cnf <<EOF
[req]
distinguished_name = req_distinguished_name
x509_extensions = v3_req
prompt = no

[req_distinguished_name]
C = ID
ST = Jawa Tengah
L = Pemalang
O = Perpustakaan Sekolah
OU = Server
CN = $IP

[v3_req]
subjectAltName = IP:$IP
EOF

openssl req -x509 -nodes -days 825 -newkey rsa:2048 \
  -keyout certs/server.key -out certs/server.crt \
  -config certs/openssl.cnf -extensions v3_req

sudo chown -R root:root certs
sudo chmod 600 certs/server.key
sudo chmod 644 certs/server.crt

.venv/bin/python -c "from app import init_db; init_db()"

sudo tee /etc/systemd/system/perpustakaan.service >/dev/null <<EOF
[Unit]
Description=Perpustakaan Sekolah Flask Gunicorn
After=network.target

[Service]
User=$USER
Group=$(id -gn)
WorkingDirectory=$APP_DIR
Environment="PATH=$APP_DIR/.venv/bin"
Environment="PYTHONUNBUFFERED=1"
ExecStart=$APP_DIR/.venv/bin/gunicorn --workers 2 --threads 2 --timeout 60 --bind 127.0.0.1:5000 app:app
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

sudo tee /etc/nginx/sites-available/perpustakaan >/dev/null <<EOF
server {
    listen 80;
    server_name $IP;
    return 301 https://\$host\$request_uri;
}

server {
    listen 443 ssl;
    server_name $IP;

    ssl_certificate $APP_DIR/certs/server.crt;
    ssl_certificate_key $APP_DIR/certs/server.key;
    ssl_protocols TLSv1.2 TLSv1.3;

    client_max_body_size 20M;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto https;
        proxy_read_timeout 60s;
    }
}
EOF

sudo rm -f /etc/nginx/sites-enabled/default
sudo ln -sf /etc/nginx/sites-available/perpustakaan /etc/nginx/sites-enabled/perpustakaan
sudo nginx -t
sudo systemctl daemon-reload
sudo systemctl enable --now perpustakaan
sudo systemctl restart nginx

echo
echo "=========================================="
echo " INSTALASI SELESAI"
echo "=========================================="
echo "Server : https://$IP/"
echo "Scan   : https://$IP/scan"
echo "Login  : admin / admin123"
echo
echo "Status:"
sudo systemctl --no-pager --full status perpustakaan | tail -n 12
echo
echo "Catatan: sertifikat HTTPS adalah self-signed untuk LAN."
echo "Di HP pilih Advanced/Lanjutan lalu lanjutkan ke situs."
