#!/bin/bash
set -e
APP_DIR="$(cd "$(dirname "$0")" && pwd)"
IP="$(hostname -I | awk '{print $1}')"
mkdir -p "$APP_DIR/certs"

cat > "$APP_DIR/certs/openssl.cnf" <<EOF
[req]
distinguished_name = req_distinguished_name
x509_extensions = v3_req
prompt = no
[req_distinguished_name]
C = ID
ST = Jawa Tengah
L = Pemalang
O = Perpustakaan Sekolah
OU = Server
CN = $IP
[v3_req]
subjectAltName = IP:$IP
EOF

openssl req -x509 -nodes -days 825 -newkey rsa:2048 \
  -keyout "$APP_DIR/certs/server.key" -out "$APP_DIR/certs/server.crt" \
  -config "$APP_DIR/certs/openssl.cnf" -extensions v3_req

sudo chmod 600 "$APP_DIR/certs/server.key"
sudo chmod 644 "$APP_DIR/certs/server.crt"

sudo sed -i "s#server_name .*;#server_name $IP;#" /etc/nginx/sites-available/perpustakaan
sudo sed -i "s#ssl_certificate .*#ssl_certificate $APP_DIR/certs/server.crt;#" /etc/nginx/sites-available/perpustakaan
sudo sed -i "s#ssl_certificate_key .*#ssl_certificate_key $APP_DIR/certs/server.key;#" /etc/nginx/sites-available/perpustakaan
sudo nginx -t
sudo systemctl restart nginx
echo "HTTPS diperbarui: https://$IP/"
