import os
import io
import sqlite3
from datetime import datetime, date, timedelta
from functools import wraps

from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, send_file, abort
from werkzeug.security import generate_password_hash, check_password_hash
import qrcode
from openpyxl import Workbook
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_PATH = os.path.join(BASE_DIR, "instance", "perpustakaan.db")
os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "ganti-secret-key-perpustakaan-2026")

def db():
    con = sqlite3.connect(DB_PATH, timeout=20)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    con.execute("PRAGMA journal_mode=WAL")
    return con

def init_db():
    con = db()
    con.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        nama TEXT NOT NULL DEFAULT 'Administrator',
        role TEXT NOT NULL DEFAULT 'admin'
    );
    CREATE TABLE IF NOT EXISTS settings (
        id INTEGER PRIMARY KEY CHECK(id=1),
        nama_sekolah TEXT NOT NULL DEFAULT 'Sekolah',
        nama_perpustakaan TEXT NOT NULL DEFAULT 'Perpustakaan Sekolah',
        alamat TEXT NOT NULL DEFAULT '',
        lama_pinjam INTEGER NOT NULL DEFAULT 7
    );
    CREATE TABLE IF NOT EXISTS siswa (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        kode TEXT UNIQUE NOT NULL,
        nisn TEXT DEFAULT '',
        nama TEXT NOT NULL,
        kelas TEXT DEFAULT '',
        jenis_kelamin TEXT DEFAULT '',
        alamat TEXT DEFAULT '',
        hp TEXT DEFAULT '',
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS buku (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        kode TEXT UNIQUE NOT NULL,
        isbn TEXT DEFAULT '',
        judul TEXT NOT NULL,
        penulis TEXT DEFAULT '',
        penerbit TEXT DEFAULT '',
        tahun TEXT DEFAULT '',
        kategori TEXT DEFAULT '',
        lokasi TEXT DEFAULT '',
        stok INTEGER NOT NULL DEFAULT 1,
        tersedia INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS transaksi (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        kode_siswa TEXT NOT NULL,
        kode_buku TEXT NOT NULL,
        jenis TEXT NOT NULL CHECK(jenis IN ('PINJAM','KEMBALI')),
        waktu TEXT NOT NULL,
        jatuh_tempo TEXT DEFAULT '',
        operator TEXT DEFAULT 'admin',
        catatan TEXT DEFAULT '',
        FOREIGN KEY(kode_siswa) REFERENCES siswa(kode),
        FOREIGN KEY(kode_buku) REFERENCES buku(kode)
    );
    CREATE INDEX IF NOT EXISTS idx_transaksi_siswa ON transaksi(kode_siswa);
    CREATE INDEX IF NOT EXISTS idx_transaksi_buku ON transaksi(kode_buku);
    """)
    if con.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0:
        con.execute("INSERT INTO users(username,password,nama,role) VALUES(?,?,?,?)",
                    ("admin", generate_password_hash("admin123"), "Administrator", "admin"))
    if con.execute("SELECT COUNT(*) FROM settings").fetchone()[0] == 0:
        con.execute("INSERT INTO settings(id) VALUES(1)")
    con.commit()
    con.close()

init_db()

def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login", next=request.path))
        return f(*args, **kwargs)
    return wrapper

@app.context_processor
def inject_globals():
    con = db()
    setting = con.execute("SELECT * FROM settings WHERE id=1").fetchone()
    con.close()
    return {"setting": setting, "logged_in": "user_id" in session}

@app.route("/")
@login_required
def index():
    con = db()
    stats = {
        "siswa": con.execute("SELECT COUNT(*) FROM siswa").fetchone()[0],
        "buku": con.execute("SELECT COUNT(*) FROM buku").fetchone()[0],
        "tersedia": con.execute("SELECT COALESCE(SUM(tersedia),0) FROM buku").fetchone()[0],
        "dipinjam": con.execute("SELECT COUNT(*) FROM transaksi WHERE jenis='PINJAM' AND id NOT IN (SELECT id FROM transaksi t2 WHERE t2.jenis='KEMBALI' AND t2.kode_siswa=transaksi.kode_siswa AND t2.kode_buku=transaksi.kode_buku AND t2.id>transaksi.id)").fetchone()[0],
        "transaksi_hari_ini": con.execute("SELECT COUNT(*) FROM transaksi WHERE date(waktu)=date('now','localtime')").fetchone()[0],
    }
    recent = con.execute("""
        SELECT t.*, s.nama nama_siswa, b.judul judul_buku
        FROM transaksi t
        JOIN siswa s ON s.kode=t.kode_siswa
        JOIN buku b ON b.kode=t.kode_buku
        ORDER BY t.id DESC LIMIT 10
    """).fetchall()
    con.close()
    return render_template("dashboard.html", stats=stats, recent=recent)

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username","").strip()
        password = request.form.get("password","")
        con = db()
        user = con.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
        con.close()
        if user and check_password_hash(user["password"], password):
            session.clear()
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            session["nama"] = user["nama"]
            return redirect(request.args.get("next") or url_for("index"))
        flash("Username atau password salah.", "danger")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/siswa")
@login_required
def siswa():
    q = request.args.get("q","").strip()
    con = db()
    if q:
        rows = con.execute("""SELECT * FROM siswa WHERE kode LIKE ? OR nisn LIKE ? OR nama LIKE ? OR kelas LIKE ? ORDER BY nama""",
                           tuple([f"%{q}%"]*4)).fetchall()
    else:
        rows = con.execute("SELECT * FROM siswa ORDER BY nama").fetchall()
    con.close()
    return render_template("siswa.html", rows=rows, q=q)

@app.route("/siswa/tambah", methods=["GET","POST"])
@login_required
def siswa_tambah():
    if request.method == "POST":
        f = request.form
        kode = f.get("kode","").strip() or "SIS-" + datetime.now().strftime("%Y%m%d%H%M%S")
        try:
            con = db()
            con.execute("""INSERT INTO siswa(kode,nisn,nama,kelas,jenis_kelamin,alamat,hp)
                           VALUES(?,?,?,?,?,?,?)""",
                        (kode,f.get("nisn","").strip(),f.get("nama","").strip(),f.get("kelas","").strip(),
                         f.get("jenis_kelamin","").strip(),f.get("alamat","").strip(),f.get("hp","").strip()))
            con.commit(); con.close()
            flash("Siswa berhasil ditambahkan.", "success")
            return redirect(url_for("siswa"))
        except sqlite3.IntegrityError as e:
            flash("Kode siswa sudah digunakan atau data tidak valid.", "danger")
    return render_template("siswa_form.html", row=None)

@app.route("/siswa/edit/<int:id>", methods=["GET","POST"])
@login_required
def siswa_edit(id):
    con = db()
    row = con.execute("SELECT * FROM siswa WHERE id=?", (id,)).fetchone()
    if not row:
        con.close(); abort(404)
    if request.method == "POST":
        f = request.form
        try:
            con.execute("""UPDATE siswa SET kode=?,nisn=?,nama=?,kelas=?,jenis_kelamin=?,alamat=?,hp=? WHERE id=?""",
                        (f.get("kode","").strip(),f.get("nisn","").strip(),f.get("nama","").strip(),
                         f.get("kelas","").strip(),f.get("jenis_kelamin","").strip(),f.get("alamat","").strip(),
                         f.get("hp","").strip(),id))
            con.commit(); con.close()
            flash("Data siswa diperbarui.", "success")
            return redirect(url_for("siswa"))
        except sqlite3.IntegrityError:
            flash("Kode siswa sudah digunakan.", "danger")
    con.close()
    return render_template("siswa_form.html", row=row)

@app.post("/siswa/hapus/<int:id>")
@login_required
def siswa_hapus(id):
    con = db()
    if con.execute("SELECT COUNT(*) FROM transaksi t JOIN siswa s ON s.kode=t.kode_siswa WHERE s.id=?", (id,)).fetchone()[0]:
        flash("Siswa tidak dapat dihapus karena memiliki riwayat transaksi.", "warning")
    else:
        con.execute("DELETE FROM siswa WHERE id=?", (id,)); con.commit()
        flash("Siswa dihapus.", "success")
    con.close()
    return redirect(url_for("siswa"))

@app.route("/buku")
@login_required
def buku():
    q = request.args.get("q","").strip()
    con = db()
    if q:
        rows = con.execute("""SELECT * FROM buku WHERE kode LIKE ? OR isbn LIKE ? OR judul LIKE ? OR penulis LIKE ? OR kategori LIKE ? ORDER BY judul""",
                           tuple([f"%{q}%"]*5)).fetchall()
    else:
        rows = con.execute("SELECT * FROM buku ORDER BY judul").fetchall()
    con.close()
    return render_template("buku.html", rows=rows, q=q)

@app.route("/buku/tambah", methods=["GET","POST"])
@login_required
def buku_tambah():
    if request.method == "POST":
        f = request.form
        kode = f.get("kode","").strip() or "BUK-" + datetime.now().strftime("%Y%m%d%H%M%S")
        try:
            stok = max(0, int(f.get("stok","1") or 1))
            con = db()
            con.execute("""INSERT INTO buku(kode,isbn,judul,penulis,penerbit,tahun,kategori,lokasi,stok,tersedia)
                           VALUES(?,?,?,?,?,?,?,?,?,?)""",
                        (kode,f.get("isbn","").strip(),f.get("judul","").strip(),f.get("penulis","").strip(),
                         f.get("penerbit","").strip(),f.get("tahun","").strip(),f.get("kategori","").strip(),
                         f.get("lokasi","").strip(),stok,stok))
            con.commit(); con.close()
            flash("Buku berhasil ditambahkan.", "success")
            return redirect(url_for("buku"))
        except (ValueError, sqlite3.IntegrityError):
            flash("Kode buku sudah digunakan atau stok tidak valid.", "danger")
    return render_template("buku_form.html", row=None)

@app.route("/buku/edit/<int:id>", methods=["GET","POST"])
@login_required
def buku_edit(id):
    con = db()
    row = con.execute("SELECT * FROM buku WHERE id=?", (id,)).fetchone()
    if not row:
        con.close(); abort(404)
    if request.method == "POST":
        f = request.form
        try:
            stok_baru = max(0, int(f.get("stok","0") or 0))
            sedang = row["stok"] - row["tersedia"]
            if stok_baru < sedang:
                flash(f"Stok tidak boleh kurang dari jumlah yang sedang dipinjam ({sedang}).", "danger")
            else:
                tersedia_baru = stok_baru - sedang
                con.execute("""UPDATE buku SET kode=?,isbn=?,judul=?,penulis=?,penerbit=?,tahun=?,kategori=?,lokasi=?,stok=?,tersedia=? WHERE id=?""",
                            (f.get("kode","").strip(),f.get("isbn","").strip(),f.get("judul","").strip(),
                             f.get("penulis","").strip(),f.get("penerbit","").strip(),f.get("tahun","").strip(),
                             f.get("kategori","").strip(),f.get("lokasi","").strip(),stok_baru,tersedia_baru,id))
                con.commit(); con.close()
                flash("Data buku diperbarui.", "success")
                return redirect(url_for("buku"))
        except (ValueError, sqlite3.IntegrityError):
            flash("Data tidak valid atau kode buku sudah digunakan.", "danger")
    con.close()
    return render_template("buku_form.html", row=row)

@app.post("/buku/hapus/<int:id>")
@login_required
def buku_hapus(id):
    con = db()
    if con.execute("SELECT COUNT(*) FROM transaksi t JOIN buku b ON b.kode=t.kode_buku WHERE b.id=?", (id,)).fetchone()[0]:
        flash("Buku tidak dapat dihapus karena memiliki riwayat transaksi.", "warning")
    else:
        con.execute("DELETE FROM buku WHERE id=?", (id,)); con.commit()
        flash("Buku dihapus.", "success")
    con.close()
    return redirect(url_for("buku"))

def active_loan(con, siswa_code, book_code):
    row = con.execute("""
        SELECT t.* FROM transaksi t
        WHERE t.kode_siswa=? AND t.kode_buku=?
        ORDER BY t.id DESC LIMIT 1
    """, (siswa_code,book_code)).fetchone()
    return row and row["jenis"] == "PINJAM"

@app.route("/scan")
@login_required
def scan():
    return render_template("scan.html")

@app.post("/api/scan/lookup")
@login_required
def scan_lookup():
    code = request.json.get("code","").strip()
    if not code:
        return jsonify(ok=False, message="Kode kosong."), 400
    con = db()
    s = con.execute("SELECT * FROM siswa WHERE kode=? OR nisn=?", (code,code)).fetchone()
    b = con.execute("SELECT * FROM buku WHERE kode=? OR isbn=?", (code,code)).fetchone()
    con.close()
    if s:
        return jsonify(ok=True, type="siswa", data=dict(s))
    if b:
        return jsonify(ok=True, type="buku", data=dict(b))
    return jsonify(ok=False, message=f"Kode {code} tidak ditemukan."), 404

@app.post("/api/scan/transaksi")
@login_required
def api_transaksi():
    data = request.json or {}
    jenis = data.get("jenis","PINJAM").upper()
    siswa_code = (data.get("kode_siswa") or "").strip()
    buku_code = (data.get("kode_buku") or "").strip()
    if jenis not in ("PINJAM","KEMBALI") or not siswa_code or not buku_code:
        return jsonify(ok=False, message="Data transaksi tidak lengkap."), 400
    con = db()
    siswa = con.execute("SELECT * FROM siswa WHERE kode=?", (siswa_code,)).fetchone()
    buku = con.execute("SELECT * FROM buku WHERE kode=?", (buku_code,)).fetchone()
    if not siswa or not buku:
        con.close(); return jsonify(ok=False, message="Siswa atau buku tidak ditemukan."), 404
    active = active_loan(con, siswa_code, buku_code)
    if jenis == "PINJAM":
        if active:
            con.close(); return jsonify(ok=False, message="Buku ini masih dipinjam oleh siswa tersebut."), 409
        if buku["tersedia"] <= 0:
            con.close(); return jsonify(ok=False, message="Stok buku sedang habis."), 409
        setting = con.execute("SELECT lama_pinjam FROM settings WHERE id=1").fetchone()
        jatuh = (date.today() + timedelta(days=int(setting["lama_pinjam"]))).isoformat()
        con.execute("UPDATE buku SET tersedia=tersedia-1 WHERE kode=?", (buku_code,))
    else:
        if not active:
            con.close(); return jsonify(ok=False, message="Tidak ada peminjaman aktif untuk kombinasi siswa dan buku ini."), 409
        jatuh = ""
        con.execute("UPDATE buku SET tersedia=MIN(stok,tersedia+1) WHERE kode=?", (buku_code,))
    con.execute("""INSERT INTO transaksi(kode_siswa,kode_buku,jenis,waktu,jatuh_tempo,operator)
                   VALUES(?,?,?,?,?,?)""",
                (siswa_code,buku_code,jenis,datetime.now().strftime("%Y-%m-%d %H:%M:%S"),jatuh,session.get("username","admin")))
    con.commit(); con.close()
    return jsonify(ok=True, message=("Peminjaman berhasil." if jenis=="PINJAM" else "Pengembalian berhasil."), siswa=dict(siswa), buku=dict(buku))

@app.route("/transaksi")
@login_required
def transaksi():
    q = request.args.get("q","").strip()
    con = db()
    sql = """SELECT t.*, s.nama nama_siswa, s.kelas, b.judul judul_buku
             FROM transaksi t JOIN siswa s ON s.kode=t.kode_siswa JOIN buku b ON b.kode=t.kode_buku"""
    params=[]
    if q:
        sql += " WHERE t.kode_siswa LIKE ? OR t.kode_buku LIKE ? OR s.nama LIKE ? OR b.judul LIKE ?"
        params=[f"%{q}%"]*4
    sql += " ORDER BY t.id DESC LIMIT 500"
    rows = con.execute(sql, params).fetchall()
    con.close()
    return render_template("transaksi.html", rows=rows, q=q)

@app.route("/qr/siswa/<kode>.png")
@login_required
def qr_siswa(kode):
    con=db(); row=con.execute("SELECT * FROM siswa WHERE kode=?", (kode,)).fetchone(); con.close()
    if not row: abort(404)
    img=qrcode.make(row["kode"])
    out=io.BytesIO(); img.save(out, format="PNG"); out.seek(0)
    return send_file(out,mimetype="image/png")

@app.route("/qr/buku/<kode>.png")
@login_required
def qr_buku(kode):
    con=db(); row=con.execute("SELECT * FROM buku WHERE kode=?", (kode,)).fetchone(); con.close()
    if not row: abort(404)
    img=qrcode.make(row["kode"])
    out=io.BytesIO(); img.save(out, format="PNG"); out.seek(0)
    return send_file(out,mimetype="image/png")

@app.route("/export/<kind>.xlsx")
@login_required
def export_xlsx(kind):
    con=db()
    if kind=="siswa":
        rows=con.execute("SELECT kode,nisn,nama,kelas,jenis_kelamin,alamat,hp FROM siswa ORDER BY nama").fetchall()
        headers=["Kode","NISN","Nama","Kelas","Jenis Kelamin","Alamat","HP"]
    elif kind=="buku":
        rows=con.execute("SELECT kode,isbn,judul,penulis,penerbit,tahun,kategori,lokasi,stok,tersedia FROM buku ORDER BY judul").fetchall()
        headers=["Kode","ISBN","Judul","Penulis","Penerbit","Tahun","Kategori","Lokasi","Stok","Tersedia"]
    elif kind=="transaksi":
        rows=con.execute("""SELECT t.waktu,t.jenis,t.kode_siswa,s.nama,t.kode_buku,b.judul,t.jatuh_tempo,t.operator
                            FROM transaksi t JOIN siswa s ON s.kode=t.kode_siswa JOIN buku b ON b.kode=t.kode_buku ORDER BY t.id DESC""").fetchall()
        headers=["Waktu","Jenis","Kode Siswa","Nama Siswa","Kode Buku","Judul Buku","Jatuh Tempo","Operator"]
    else:
        con.close(); abort(404)
    con.close()
    wb=Workbook(); ws=wb.active; ws.title=kind.capitalize()
    ws.append(headers)
    for r in rows: ws.append([r[h.lower().replace(" ","_")] if h.lower().replace(" ","_") in r.keys() else r[i] for i,h in enumerate(headers)])
    out=io.BytesIO(); wb.save(out); out.seek(0)
    return send_file(out,as_attachment=True,download_name=f"{kind}_{date.today().isoformat()}.xlsx",
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")

@app.route("/export/transaksi.pdf")
@login_required
def export_pdf():
    con=db()
    rows=con.execute("""SELECT t.waktu,t.jenis,s.nama nama_siswa,b.judul judul_buku,t.jatuh_tempo
                        FROM transaksi t JOIN siswa s ON s.kode=t.kode_siswa JOIN buku b ON b.kode=t.kode_buku
                        ORDER BY t.id DESC LIMIT 1000""").fetchall()
    con.close()
    out=io.BytesIO()
    doc=SimpleDocTemplate(out,pagesize=A4,rightMargin=24,leftMargin=24,topMargin=28,bottomMargin=28)
    styles=getSampleStyleSheet()
    story=[Paragraph("Laporan Transaksi Perpustakaan",styles["Title"]),Spacer(1,10)]
    data=[["Waktu","Jenis","Siswa","Buku","Jatuh Tempo"]]
    for r in rows: data.append([r["waktu"],r["jenis"],r["nama_siswa"],r["judul_buku"],r["jatuh_tempo"] or "-"])
    table=Table(data,repeatRows=1,colWidths=[80,55,120,170,75])
    table.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#212529")),
                               ("TEXTCOLOR",(0,0),(-1,0),colors.white),("GRID",(0,0),(-1,-1),0.3,colors.grey),
                               ("FONTSIZE",(0,0),(-1,-1),7),("VALIGN",(0,0),(-1,-1),"TOP")]))
    story.append(table); doc.build(story); out.seek(0)
    return send_file(out,as_attachment=True,download_name=f"transaksi_{date.today().isoformat()}.pdf",mimetype="application/pdf")

@app.route("/pengaturan", methods=["GET","POST"])
@login_required
def pengaturan():
    con=db()
    if request.method=="POST":
        f=request.form
        con.execute("""UPDATE settings SET nama_sekolah=?,nama_perpustakaan=?,alamat=?,lama_pinjam=? WHERE id=1""",
                    (f.get("nama_sekolah","").strip() or "Sekolah",
                     f.get("nama_perpustakaan","").strip() or "Perpustakaan Sekolah",
                     f.get("alamat","").strip(),max(1,int(f.get("lama_pinjam","7") or 7))))
        con.commit(); flash("Pengaturan disimpan.","success")
    row=con.execute("SELECT * FROM settings WHERE id=1").fetchone(); con.close()
    return render_template("pengaturan.html",row=row)

@app.route("/backup")
@login_required
def backup():
    if not os.path.exists(DB_PATH): abort(404)
    return send_file(DB_PATH,as_attachment=True,download_name=f"backup_perpustakaan_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db",
                     mimetype="application/octet-stream")

@app.errorhandler(404)
def not_found(e):
    return render_template("error.html", code=404, message="Halaman tidak ditemukan."), 404

@app.errorhandler(500)
def server_error(e):
    return render_template("error.html", code=500, message="Terjadi kesalahan pada server."), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
