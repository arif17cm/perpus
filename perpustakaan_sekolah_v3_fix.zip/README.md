# Perpustakaan Sekolah V3 — HTTPS LAN

Versi ini memperbaiki error `ERR_SSL_PROTOCOL_ERROR` dengan memastikan port 5000 dijalankan **HTTPS**, bukan HTTP.

## Instalasi baru
```bash
unzip perpustakaan_sekolah_v3.zip
cd perpustakaan_sekolah_v3
sudo apt update
sudo apt install -y openssl python3-venv
./run_https.sh
```

Script akan menghentikan proses lama yang memakai port 5000, memasang dependensi, membuat sertifikat LAN, lalu menjalankan Flask HTTPS.

## Jika folder V3 sudah ada
Salin versi ini ke folder baru, atau ekstrak ulang setelah menghentikan aplikasi lama.

Jika Anda pernah menjalankan V2/V3 lama, pastikan proses lama di port 5000 berhenti:
```bash
sudo fuser -k 5000/tcp
```

Lalu:
```bash
./run_https.sh
```

## Akses dari HP
Cari IP server:
```bash
hostname -I
```
Misalnya `192.168.1.104`, buka:
```text
https://192.168.1.104:5000/scan
```

Browser akan memberi peringatan karena sertifikat ini adalah sertifikat lokal/self-signed. Pilih **Lanjutan/Advanced** lalu lanjutkan ke situs. Setelah halaman terbuka, pilih **Allow/Izinkan** kamera.

**Jangan menggunakan `http://192.168.1.104:5000` untuk kamera.** Gunakan `https://...`.

Login awal:
- Username: `admin`
- Password: `admin123`

Fitur: dashboard, siswa, buku, import/export Excel, kartu QR, label QR, scan kamera, scanner USB, peminjaman/pengembalian, laporan, backup dan pengaturan.
