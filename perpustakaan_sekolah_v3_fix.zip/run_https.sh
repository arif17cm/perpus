#!/bin/bash
set -e
cd "$(dirname "$0")"
if ! command -v openssl >/dev/null 2>&1; then
  echo "OpenSSL belum terpasang. Jalankan: sudo apt update && sudo apt install -y openssl"
  exit 1
fi
# Stop old HTTP/Flask instance occupying port 5000, if any.
if command -v fuser >/dev/null 2>&1; then
  fuser -k 5000/tcp 2>/dev/null || true
  sleep 1
fi
if [ ! -d .venv ]; then
  python3 -m venv .venv
fi
. .venv/bin/activate
python -m pip install -r requirements.txt
python app.py
