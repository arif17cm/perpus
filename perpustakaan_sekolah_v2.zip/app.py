import os, io, sqlite3, zipfile
from datetime import date, timedelta
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify, send_file
from werkzeug.security import generate_password_hash, check_password_hash
from openpyxl import Workbook, load_workbook
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.units import mm
from reportlab.lib.utils import ImageReader
import qrcode

BASE=os.path.abspath(os.path.dirname(__file__))
DB=os.path.join(BASE,"instance","perpustakaan.db")
UPLOAD=os.path.join(BASE,"uploads")
app=Flask(__name__); app.secret_key=os.environ.get("SECRET_KEY","ganti-secret-key"); app.config["DB"]=DB

def db():
    os.makedirs(os.path.dirname(DB),exist_ok=True); c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; c.execute("PRAGMA foreign_keys=ON"); return c
def init():
    c=db(); c.executescript("""
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT UNIQUE NOT NULL,password TEXT NOT NULL,nama TEXT NOT NULL,role TEXT DEFAULT 'admin');
    CREATE TABLE IF NOT EXISTS siswa(id INTEGER PRIMARY KEY AUTOINCREMENT,nisn TEXT UNIQUE,nama TEXT NOT NULL,kelas TEXT,kode_barcode TEXT UNIQUE,alamat TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS buku(id INTEGER PRIMARY KEY AUTOINCREMENT,kode_buku TEXT UNIQUE NOT NULL,isbn TEXT,judul TEXT NOT NULL,pengarang TEXT,penerbit TEXT,tahun INTEGER,kategori TEXT,rak TEXT,jumlah INTEGER DEFAULT 1,tersedia INTEGER DEFAULT 1,barcode TEXT UNIQUE,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS peminjaman(id INTEGER PRIMARY KEY AUTOINCREMENT,siswa_id INTEGER NOT NULL,buku_id INTEGER NOT NULL,tanggal_pinjam TEXT NOT NULL,batas_kembali TEXT NOT NULL,tanggal_kembali TEXT,status TEXT DEFAULT 'DIPINJAM',FOREIGN KEY(siswa_id) REFERENCES siswa(id),FOREIGN KEY(buku_id) REFERENCES buku(id));
    CREATE TABLE IF NOT EXISTS pengaturan(id INTEGER PRIMARY KEY CHECK(id=1),nama_sekolah TEXT DEFAULT 'SDN 01 BANGLARANGAN',nama_perpustakaan TEXT DEFAULT 'Perpustakaan Sekolah',alamat TEXT DEFAULT '',lama_pinjam INTEGER DEFAULT 7,logo TEXT);
    """)
    if not c.execute("SELECT id FROM users WHERE username='admin'").fetchone(): c.execute("INSERT INTO users(username,password,nama) VALUES(?,?,?)",("admin",generate_password_hash("admin123"),"Administrator"))
    if not c.execute("SELECT id FROM pengaturan WHERE id=1").fetchone(): c.execute("INSERT INTO pengaturan(id) VALUES(1)")
    c.commit(); c.close()
def login_required(f):
    @wraps(f)
    def w(*a,**k):
        if "user_id" not in session:return redirect(url_for("login"))
        return f(*a,**k)
    return w
@app.context_processor
def ctx():
    c=db(); s=c.execute("SELECT * FROM pengaturan WHERE id=1").fetchone(); c.close()
    return {"setting":s,"today":date.today().isoformat()}
@app.route("/login",methods=["GET","POST"])
def login():
    if request.method=="POST":
        c=db(); u=c.execute("SELECT * FROM users WHERE username=?",(request.form["username"].strip(),)).fetchone(); c.close()
        if u and check_password_hash(u["password"],request.form["password"]): session["user_id"]=u["id"];session["nama"]=u["nama"];return redirect(url_for("dashboard"))
        flash("Username atau password salah","danger")
    return render_template("login.html")
@app.get("/logout")
def logout():session.clear();return redirect(url_for("login"))

@app.get("/")
@login_required
def dashboard():
    c=db(); st={}
    for k,q in {"siswa":"SELECT COUNT(*) n FROM siswa","buku":"SELECT COALESCE(SUM(jumlah),0) n FROM buku","tersedia":"SELECT COALESCE(SUM(tersedia),0) n FROM buku","dipinjam":"SELECT COUNT(*) n FROM peminjaman WHERE status='DIPINJAM'","terlambat":"SELECT COUNT(*) n FROM peminjaman WHERE status='DIPINJAM' AND batas_kembali<?","hari_ini":"SELECT COUNT(*) n FROM peminjaman WHERE tanggal_pinjam=?"}.items():
        arg=(date.today().isoformat(),) if k=="terlambat" else ((date.today().isoformat(),) if k=="hari_ini" else ())
        st[k]=c.execute(q,arg).fetchone()["n"]
    chart=c.execute("""SELECT tanggal_pinjam t,COUNT(*) n FROM peminjaman WHERE tanggal_pinjam>=date('now','-6 day') GROUP BY tanggal_pinjam ORDER BY tanggal_pinjam""").fetchall()
    popular=c.execute("""SELECT b.judul,COUNT(*) n FROM peminjaman p JOIN buku b ON b.id=p.buku_id GROUP BY b.id ORDER BY n DESC LIMIT 10""").fetchall()
    recent=c.execute("""SELECT p.*,s.nama siswa,s.kelas,b.judul FROM peminjaman p JOIN siswa s ON s.id=p.siswa_id JOIN buku b ON b.id=p.buku_id ORDER BY p.id DESC LIMIT 10""").fetchall();c.close()
    return render_template("dashboard.html",st=st,chart=chart,popular=popular,recent=recent)

def crud_siswa():
    c=db(); rows=c.execute("SELECT * FROM siswa ORDER BY nama").fetchall();c.close();return rows
@app.get("/siswa")
@login_required
def siswa():
    q=request.args.get("q","").strip(); c=db()
    rows=c.execute("SELECT * FROM siswa WHERE nama LIKE ? OR nisn LIKE ? OR kelas LIKE ? OR kode_barcode LIKE ? ORDER BY nama",tuple([f"%{q}%"]*4)).fetchall() if q else c.execute("SELECT * FROM siswa ORDER BY nama").fetchall();c.close()
    return render_template("siswa.html",rows=rows,q=q)
@app.route("/siswa/form/<int:id>",methods=["GET","POST"])
@app.route("/siswa/form",defaults={"id":0},methods=["GET","POST"])
@login_required
def siswa_form(id):
    c=db(); row=c.execute("SELECT * FROM siswa WHERE id=?",(id,)).fetchone() if id else None
    if request.method=="POST":
        d=[request.form.get(x,"").strip() for x in ["nisn","nama","kelas","kode_barcode","alamat"]]
        try:
            if id:c.execute("UPDATE siswa SET nisn=?,nama=?,kelas=?,kode_barcode=?,alamat=? WHERE id=?",(*d,id))
            else:c.execute("INSERT INTO siswa(nisn,nama,kelas,kode_barcode,alamat) VALUES(?,?,?,?,?)",d)
            c.commit();c.close();flash("Data siswa disimpan","success");return redirect(url_for("siswa"))
        except sqlite3.IntegrityError: flash("NISN/barcode sudah digunakan","danger")
    c.close();return render_template("siswa_form.html",row=row)
@app.post("/siswa/hapus/<int:id>")
@login_required
def siswa_hapus(id):
    c=db()
    try:c.execute("DELETE FROM siswa WHERE id=?",(id,));c.commit();flash("Siswa dihapus","success")
    except sqlite3.IntegrityError:flash("Siswa memiliki riwayat transaksi","danger")
    c.close();return redirect(url_for("siswa"))

@app.get("/buku")
@login_required
def buku():
    q=request.args.get("q","").strip();c=db()
    sql="SELECT * FROM buku WHERE judul LIKE ? OR kode_buku LIKE ? OR isbn LIKE ? OR barcode LIKE ? OR pengarang LIKE ? ORDER BY judul"
    rows=c.execute(sql,tuple([f"%{q}%"]*5)).fetchall() if q else c.execute("SELECT * FROM buku ORDER BY judul").fetchall();c.close()
    return render_template("buku.html",rows=rows,q=q)
@app.route("/buku/form/<int:id>",methods=["GET","POST"])
@app.route("/buku/form",defaults={"id":0},methods=["GET","POST"])
@login_required
def buku_form(id):
    c=db();row=c.execute("SELECT * FROM buku WHERE id=?",(id,)).fetchone() if id else None
    if request.method=="POST":
        fs=["kode_buku","isbn","judul","pengarang","penerbit","tahun","kategori","rak","jumlah","barcode"];d=[request.form.get(x,"").strip() for x in fs]
        try:
            jumlah=max(1,int(d[8] or 1));dip=(row["jumlah"]-row["tersedia"]) if row else 0
            if jumlah<dip:raise ValueError
            tersedia=jumlah-dip
            if id:c.execute("""UPDATE buku SET kode_buku=?,isbn=?,judul=?,pengarang=?,penerbit=?,tahun=?,kategori=?,rak=?,jumlah=?,tersedia=?,barcode=? WHERE id=?""",(*d[:8],jumlah,tersedia,d[9],id))
            else:c.execute("""INSERT INTO buku(kode_buku,isbn,judul,pengarang,penerbit,tahun,kategori,rak,jumlah,tersedia,barcode) VALUES(?,?,?,?,?,?,?,?,?,?,?)""",(*d[:8],jumlah,jumlah,d[9]))
            c.commit();c.close();flash("Data buku disimpan","success");return redirect(url_for("buku"))
        except (sqlite3.IntegrityError,ValueError):flash("Data tidak valid atau kode/barcode sudah digunakan","danger")
    c.close();return render_template("buku_form.html",row=row)
@app.post("/buku/hapus/<int:id>")
@login_required
def buku_hapus(id):
    c=db()
    try:c.execute("DELETE FROM buku WHERE id=?",(id,));c.commit();flash("Buku dihapus","success")
    except sqlite3.IntegrityError:flash("Buku memiliki riwayat transaksi","danger")
    c.close();return redirect(url_for("buku"))

@app.get("/scan")
@login_required
def scan():return render_template("scan.html")
@app.get("/api/scan/<kode>")
@login_required
def scan_api(kode):
    c=db();s=c.execute("SELECT * FROM siswa WHERE kode_barcode=? OR nisn=?",(kode,kode)).fetchone();b=c.execute("SELECT * FROM buku WHERE barcode=? OR kode_buku=? OR isbn=?",(kode,kode,kode)).fetchone();c.close()
    return jsonify(siswa=dict(s) if s else None,buku=dict(b) if b else None)
@app.post("/api/quick")
@login_required
def quick():
    x=request.get_json() or {};sk=str(x.get("siswa","")).strip();bk=str(x.get("buku","")).strip();act=x.get("action","pinjam");c=db()
    s=c.execute("SELECT * FROM siswa WHERE kode_barcode=? OR nisn=?",(sk,sk)).fetchone();b=c.execute("SELECT * FROM buku WHERE barcode=? OR kode_buku=? OR isbn=?",(bk,bk,bk)).fetchone()
    if not s or not b:c.close();return jsonify(ok=False,message="Siswa atau buku tidak ditemukan"),400
    try:
        c.execute("BEGIN IMMEDIATE")
        if act=="pinjam":
            if b["tersedia"]<1:raise ValueError("Buku tidak tersedia")
            lama=c.execute("SELECT lama_pinjam FROM pengaturan WHERE id=1").fetchone()["lama_pinjam"] or 7; batas=date.today()+timedelta(days=lama)
            c.execute("INSERT INTO peminjaman(siswa_id,buku_id,tanggal_pinjam,batas_kembali,status) VALUES(?,?,?,?, 'DIPINJAM')",(s["id"],b["id"],date.today().isoformat(),batas.isoformat()));c.execute("UPDATE buku SET tersedia=tersedia-1 WHERE id=?",(b["id"],));msg=f"{b['judul']} dipinjam oleh {s['nama']}"
        else:
            p=c.execute("SELECT * FROM peminjaman WHERE siswa_id=? AND buku_id=? AND status='DIPINJAM' ORDER BY id DESC LIMIT 1",(s["id"],b["id"])).fetchone()
            if not p:raise ValueError("Peminjaman aktif tidak ditemukan")
            c.execute("UPDATE peminjaman SET tanggal_kembali=?,status='KEMBALI' WHERE id=?",(date.today().isoformat(),p["id"]));c.execute("UPDATE buku SET tersedia=MIN(jumlah,tersedia+1) WHERE id=?",(b["id"],));msg=f"{b['judul']} dikembalikan oleh {s['nama']}"
        c.commit();return jsonify(ok=True,message=msg)
    except Exception as e:c.rollback();return jsonify(ok=False,message=str(e)),400
    finally:c.close()

@app.get("/transaksi")
@login_required
def transaksi():
    q=request.args.get("q","");status=request.args.get("status","");c=db()
    sql="""SELECT p.*,s.nama siswa,s.kelas,b.judul FROM peminjaman p JOIN siswa s ON s.id=p.siswa_id JOIN buku b ON b.id=p.buku_id WHERE 1=1""";a=[]
    if q:sql+=" AND (s.nama LIKE ? OR b.judul LIKE ? OR s.nisn LIKE ?)";a += [f"%{q}%"]*3
    if status:sql+=" AND p.status=?";a.append(status)
    sql+=" ORDER BY p.id DESC";rows=c.execute(sql,a).fetchall();c.close();return render_template("transaksi.html",rows=rows,q=q,status=status)
@app.post("/kembali/<int:id>")
@login_required
def kembali(id):
    c=db()
    try:
        c.execute("BEGIN IMMEDIATE");p=c.execute("SELECT * FROM peminjaman WHERE id=? AND status='DIPINJAM'",(id,)).fetchone()
        if not p:raise ValueError
        c.execute("UPDATE peminjaman SET tanggal_kembali=?,status='KEMBALI' WHERE id=?",(date.today().isoformat(),id));c.execute("UPDATE buku SET tersedia=MIN(jumlah,tersedia+1) WHERE id=?",(p["buku_id"],));c.commit();flash("Buku dikembalikan","success")
    except: c.rollback();flash("Pengembalian gagal","danger")
    c.close();return redirect(url_for("transaksi"))

@app.get("/import")
@login_required
def import_page():return render_template("import.html")
def xlsx_response(wb,name):
    out=io.BytesIO();wb.save(out);out.seek(0);return send_file(out,as_attachment=True,download_name=name,mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
@app.get("/import/template/<jenis>")
@login_required
def template(jenis):
    wb=Workbook();ws=wb.active
    if jenis=="siswa":ws.append(["nisn","nama","kelas","kode_barcode","alamat"]);ws.append(["1234567890","Contoh Siswa","VI","SIS-0001",""])
    else:ws.append(["kode_buku","isbn","judul","pengarang","penerbit","tahun","kategori","rak","jumlah","barcode"]);ws.append(["BK-0001","","Contoh Buku","Penulis","Penerbit",2026,"Pelajaran","A-01",1,"BK-0001"])
    return xlsx_response(wb,f"template_{jenis}.xlsx")
@app.post("/import/<jenis>")
@login_required
def do_import(jenis):
    f=request.files.get("file")
    if not f or not f.filename.endswith(".xlsx"):flash("Pilih file XLSX","danger");return redirect(url_for("import_page"))
    wb=load_workbook(f,read_only=True,data_only=True);ws=wb.active;headers=[str(x.value).strip().lower() if x.value else "" for x in next(ws.iter_rows())];c=db();ok=0;skip=0
    try:
        for row in ws.iter_rows(min_row=2,values_only=True):
            d=dict(zip(headers,row))
            try:
                if jenis=="siswa":
                    if not d.get("nama"):continue
                    c.execute("INSERT INTO siswa(nisn,nama,kelas,kode_barcode,alamat) VALUES(?,?,?,?,?)",(str(d.get("nisn") or "").strip() or None,str(d["nama"]).strip(),str(d.get("kelas") or "").strip(),str(d.get("kode_barcode") or "").strip() or None,str(d.get("alamat") or "").strip()));ok+=1
                else:
                    if not d.get("judul") or not d.get("kode_buku"):continue
                    n=max(1,int(d.get("jumlah") or 1));c.execute("""INSERT INTO buku(kode_buku,isbn,judul,pengarang,penerbit,tahun,kategori,rak,jumlah,tersedia,barcode) VALUES(?,?,?,?,?,?,?,?,?,?,?)""",(str(d["kode_buku"]).strip(),str(d.get("isbn") or "").strip() or None,str(d["judul"]).strip(),str(d.get("pengarang") or "").strip(),str(d.get("penerbit") or "").strip(),int(d["tahun"]) if d.get("tahun") else None,str(d.get("kategori") or "").strip(),str(d.get("rak") or "").strip(),n,n,str(d.get("barcode") or "").strip() or None));ok+=1
            except Exception:skip+=1
        c.commit()
    finally:c.close()
    flash(f"Import selesai: {ok} berhasil, {skip} dilewati.","success");return redirect(url_for("import_page"))

@app.get("/export/<jenis>")
@login_required
def export(jenis):
    c=db();wb=Workbook();ws=wb.active
    if jenis=="siswa":
        rows=c.execute("SELECT nisn,nama,kelas,kode_barcode,alamat FROM siswa ORDER BY nama").fetchall();ws.append(["NISN","Nama","Kelas","Kode Barcode","Alamat"])
    else:
        rows=c.execute("SELECT kode_buku,isbn,judul,pengarang,penerbit,tahun,kategori,rak,jumlah,tersedia,barcode FROM buku ORDER BY judul").fetchall();ws.append(["Kode","ISBN","Judul","Pengarang","Penerbit","Tahun","Kategori","Rak","Jumlah","Tersedia","Barcode"])
    for r in rows:ws.append(list(r));c.close()
    return xlsx_response(wb,f"{jenis}.xlsx")

def qr_img(data):
    q=qrcode.make(str(data));bio=io.BytesIO();q.save(bio,format="PNG");bio.seek(0);return ImageReader(bio)
@app.get("/cetak/kartu")
@login_required
def kartu():
    ids=request.args.get("ids","").strip();c=db();rows=c.execute("SELECT * FROM siswa ORDER BY nama").fetchall() if not ids else c.execute("SELECT * FROM siswa WHERE id IN (%s)"%(",".join("?"*len(ids.split(",")))),[int(x) for x in ids.split(",")]).fetchall();c.close()
    out=io.BytesIO();p=canvas.Canvas(out,pagesize=A4);W,H=A4
    for i,r in enumerate(rows):
        x=15*mm+(i%2)*92*mm;y=H-35*mm-(i//2%4)*62*mm
        p.roundRect(x,y,85*mm,52*mm,4*mm,stroke=1,fill=0);p.setFont("Helvetica-Bold",10);p.drawString(x+5*mm,y+43*mm,ctx_setting()["nama_sekolah"]);p.setFont("Helvetica-Bold",12);p.drawString(x+5*mm,y+34*mm,"KARTU ANGGOTA");p.setFont("Helvetica",9);p.drawString(x+5*mm,y+25*mm,f"Nama : {r['nama']}");p.drawString(x+5*mm,y+18*mm,f"NISN : {r['nisn'] or '-'}");p.drawString(x+5*mm,y+11*mm,f"Kelas: {r['kelas'] or '-'}");code=r["kode_barcode"] or r["nisn"] or f"SIS-{r['id']}";p.drawImage(qr_img(code),x+61*mm,y+5*mm,20*mm,20*mm);p.drawCentredString(x+71*mm,y+3*mm,code)
        if i%8==7:p.showPage()
    p.save();out.seek(0);return send_file(out,as_attachment=True,download_name="kartu_anggota.pdf",mimetype="application/pdf")
def ctx_setting():
    c=db();r=c.execute("SELECT * FROM pengaturan WHERE id=1").fetchone();c.close();return r
@app.get("/cetak/label")
@login_required
def label():
    c=db();rows=c.execute("SELECT * FROM buku ORDER BY judul").fetchall();c.close();out=io.BytesIO();p=canvas.Canvas(out,pagesize=A4);W,H=A4
    for i,r in enumerate(rows):
        x=12*mm+(i%3)*63*mm;y=H-25*mm-(i//3%10)*27*mm;p.roundRect(x,y,58*mm,22*mm,2*mm);p.setFont("Helvetica-Bold",7);p.drawString(x+2*mm,y+16*mm,r["judul"][:35]);p.setFont("Helvetica",6);p.drawString(x+2*mm,y+11*mm,f"Kode: {r['kode_buku']}  Rak: {r['rak'] or '-'}");code=r["barcode"] or r["kode_buku"];p.drawImage(qr_img(code),x+43*mm,y+2*mm,16*mm,16*mm)
        if i%30==29:p.showPage()
    p.save();out.seek(0);return send_file(out,as_attachment=True,download_name="label_buku.pdf",mimetype="application/pdf")

@app.get("/laporan")
@login_required
def laporan():
    c=db();rows=c.execute("""SELECT p.*,s.nama siswa,s.kelas,b.judul FROM peminjaman p JOIN siswa s ON s.id=p.siswa_id JOIN buku b ON b.id=p.buku_id ORDER BY p.id DESC""").fetchall();c.close();return render_template("laporan.html",rows=rows)
@app.get("/laporan/excel")
@login_required
def laporan_excel():
    c=db();rows=c.execute("""SELECT p.tanggal_pinjam,p.batas_kembali,p.tanggal_kembali,p.status,s.nama,s.kelas,b.judul,b.kode_buku FROM peminjaman p JOIN siswa s ON s.id=p.siswa_id JOIN buku b ON b.id=p.buku_id ORDER BY p.id DESC""").fetchall();c.close();wb=Workbook();ws=wb.active;ws.append(["Tanggal Pinjam","Batas","Tanggal Kembali","Status","Siswa","Kelas","Buku","Kode Buku"]);[ws.append(list(r)) for r in rows];return xlsx_response(wb,"laporan_peminjaman.xlsx")
@app.get("/laporan/pdf")
@login_required
def laporan_pdf():
    c=db();rows=c.execute("""SELECT p.tanggal_pinjam,p.batas_kembali,p.tanggal_kembali,p.status,s.nama,s.kelas,b.judul FROM peminjaman p JOIN siswa s ON s.id=p.siswa_id JOIN buku b ON b.id=p.buku_id ORDER BY p.id DESC""").fetchall();c.close();out=io.BytesIO();p=canvas.Canvas(out,pagesize=A4);W,H=A4;y=H-20*mm;p.setFont("Helvetica-Bold",14);p.drawString(15*mm,y,ctx_setting()["nama_perpustakaan"]);y-=8*mm;p.setFont("Helvetica",8)
    for r in rows:
        line=f"{r['tanggal_pinjam']} | {r['siswa'][:22]} | {r['judul'][:30]} | {r['status']}";p.drawString(15*mm,y,line);y-=5*mm
        if y<15*mm:p.showPage();y=H-15*mm
    p.save();out.seek(0);return send_file(out,as_attachment=True,download_name="laporan.pdf",mimetype="application/pdf")

@app.route("/pengaturan",methods=["GET","POST"])
@login_required
def pengaturan():
    c=db();r=c.execute("SELECT * FROM pengaturan WHERE id=1").fetchone()
    if request.method=="POST":
        c.execute("UPDATE pengaturan SET nama_sekolah=?,nama_perpustakaan=?,alamat=?,lama_pinjam=? WHERE id=1",(request.form["nama_sekolah"],request.form["nama_perpustakaan"],request.form["alamat"],max(1,int(request.form["lama_pinjam"] or 7))))
        c.commit();c.close();flash("Pengaturan disimpan","success");return redirect(url_for("pengaturan"))
    c.close();return render_template("pengaturan.html",row=r)
@app.get("/backup")
@login_required
def backup():
    if not os.path.exists(DB):init()
    return send_file(DB,as_attachment=True,download_name=f"backup_perpustakaan_{date.today().isoformat()}.db",mimetype="application/octet-stream")

if __name__=="__main__":init();app.run(host="0.0.0.0",port=5000,debug=True)
