# Perpustakaan Sekolah V2

Flask + SQLite. V2 menambahkan:
- import/export Excel siswa & buku
- template Excel
- cetak kartu anggota PDF dengan QR
- cetak label buku PDF dengan QR
- scan QR kamera
- peminjaman/pengembalian
- laporan Excel/PDF
- backup database
- pengaturan sekolah & logo
- dashboard grafik
- login admin

Instalasi:
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Buka http://127.0.0.1:5000
Login awal: admin / admin123

Untuk LAN:
http://IP-SERVER:5000

Catatan kamera:
akses kamera browser biasanya memerlukan HTTPS atau localhost. Scanner USB tetap dapat digunakan pada input kode.
